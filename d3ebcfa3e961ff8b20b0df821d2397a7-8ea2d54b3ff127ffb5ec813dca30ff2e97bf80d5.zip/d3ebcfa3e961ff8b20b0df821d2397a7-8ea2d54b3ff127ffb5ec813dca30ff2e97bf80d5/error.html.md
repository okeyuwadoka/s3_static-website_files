Use a text editor to create this file. I'm using `Atom`.

```r
<html>
<h1>404</h1>
<h2>Page not found</h2>
<p>
The page you are trying to access does not exist.
</p>
</html>
```

<details>
<summary>🔴 See in Atom</summary>
<p> 
  
[![isaac-arnault-aws-3.png](https://i.postimg.cc/9QBdNxL4/isaac-arnault-aws-3.png)](https://postimg.cc/fVJSVvnZ)

</p>
</details>