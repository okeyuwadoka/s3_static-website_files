Use a text editor to create this file. I'm using `Atom` editor.

```r
<html>
<h1>My S3 static website</h1>
<img src="https://bit.ly/33ovy7X" alt="Beerus Sama">
</html>
```

<details>
<summary>🔴 See in Atom</summary>
<p> 
  
[![isaac-arnault-aws-1.png](https://i.postimg.cc/Pq3mdCsT/isaac-arnault-aws-1.png)](https://postimg.cc/VStSRLkV)

</p>
</details>