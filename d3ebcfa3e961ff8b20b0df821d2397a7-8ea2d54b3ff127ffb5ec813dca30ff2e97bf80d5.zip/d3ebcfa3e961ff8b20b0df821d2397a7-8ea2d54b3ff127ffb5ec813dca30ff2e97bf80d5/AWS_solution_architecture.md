<details>
<summary>🔵 See architecture</summary>
<p> 
  
[![isaac-arnault-aws-solution-architect.png](https://i.postimg.cc/15KgSrtx/isaac-arnault-aws-solution-architect.png)](https://postimg.cc/Yhh2fgY8)

</p>
</details>