Use a text editor to create this file. I'm using `Atom`.

```r
<html>
<h1>About</h1>
<h2><a href="/index.html" target="_blank">Back to home</a></h2>
<p>
A static website hosted on AWS. <br>
You can deploy a similar website for free in about 5 minutes.<br>
<a href="https://github.com/isaacarnault/aws-s3-static-website" target="_blank">Instructions</a>. <br>
<b>Good luck!</b>
</html>
```

<details>
<summary>🔴 See in Atom</summary>
<p> 

[![2.png](https://i.postimg.cc/vZX2sGQM/2.png)](https://postimg.cc/21b7dRbX)

</p>
</details>